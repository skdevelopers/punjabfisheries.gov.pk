{{-- resources/views/blog-details.blade.php --}}
@php
    use Illuminate\Support\Facades\Storage;
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="{{ $post->meta_description ?? Str::limit(strip_tags($post->excerpt ?? $post->content ?? ''), 160) }}" />
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-eval' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com https://cdn.plyr.io; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.plyr.io; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'; media-src 'self' https:; object-src 'none'; base-uri 'self'; form-action 'self';" />
    <link rel="shortcut icon" href="{{ asset('assets/images/favicon.ico') }}" type="image/x-icon" />
    <link rel="preconnect" href="https://fonts.googleapis.com/" />
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
    <title>{{ $post->title }} — Punjab Fisheries</title>
    <script defer src="{{ asset('assets/js/app.min.js') }}"></script>
    <link href="{{ asset('assets/css/styles.css') }}" rel="stylesheet">
</head>

<body>
    <!-- loader -->
    <div class="screen_loader fixed inset-0 z-[101] grid place-content-center bg-neutral-0">
        <div class="w-10 h-10 border-4 border-t-primary-400 border-neutral-40 rounded-full animate-spin"></div>
    </div>

    @include('frontend.layouts.header')

    <!-- Page Header -->
    <section class="pt-32 pb-20 bg-gradient-to-r from-blue-50 to-green-50">
        <div class="cont">
            <!-- Breadcrumb -->
            <nav class="mb-8">
                <ol class="flex items-center space-x-2 text-sm text-gray-600">
                    <li><a href="{{ route('frontend.home') }}" class="hover:text-primary-600">Home</a></li>
                    <li class="flex items-center">
                        <svg class="w-4 h-4 mx-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                        </svg>
                        <a href="{{ route('frontend.blog') }}" class="hover:text-primary-600">Blog</a>
                    </li>
                    <li class="flex items-center">
                        <svg class="w-4 h-4 mx-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="text-gray-900">Blog Details</span>
                    </li>
                </ol>
            </nav>

            <div class="text-center">
                <div class="inline-flex items-center px-4 py-2 rounded-full bg-primary-100 text-primary-800 text-sm font-medium mb-4">
                    {{ $post->category->name ?? 'Aquaculture Technology' }} - {{ $post->created_at->format('F d, Y') }}
                </div>
                <h1 class="text-4xl xl:text-5xl font-bold text-neutral-900 mb-6">{{ $post->title }}</h1>
                <p class="text-lg text-neutral-600 max-w-3xl mx-auto leading-relaxed">{{ $post->excerpt }}</p>
            </div>
        </div>
    </section>

    <!-- Blog Details section start -->
    <section class="bg-neutral-0 py-120">
        <div class="cont grid grid-cols-12 gap-6">
            <div class="col-span-12 md:col-span-7 xl:col-span-8">
                <div class="relative">
                    <div class="relative z-[1]">
                    @if($post->featured_image)
                            <img src="{{ Storage::url($post->featured_image) }}" class="reveal_anim rounded-xl w-full mb-10 xl:mb-10" alt="{{ $post->title }}" />
                        @endif
                        <p class="font-medium mb-4">{{ $post->category->name ?? 'Aquaculture Technology' }} - {{ $post->created_at->format('F d, Y') }}</p>
                        <h1 class="mb-4 xl:mb-6 reveal_anim">{{ $post->title }}</h1>

                        <div class="m-text mb-6">
                            {!! $post->content !!}
                        </div>

                        @if($post->excerpt)
                            <div class="mb-6 overflow-hidden bg-primary-50 p-4 xl:p-10 border-l-4 border-primary-500">
                                <div class="flex flex-col sm:flex-row gap-4 sm:items-center">
                                    <div class="size-12 shrink-0 f-center xl:size-[60px] bg-primary-300 rounded-full text-neutral-0">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="size-6" fill="currentColor" viewBox="0 0 256 256">
                                            <path d="M100,56H40A16,16,0,0,0,24,72v64a16,16,0,0,0,16,16h60v8a32,32,0,0,1-32,32,8,8,0,0,0,0,16,48.05,48.05,0,0,0,48-48V72A16,16,0,0,0,100,56Zm0,80H40V72h60ZM216,56H156a16,16,0,0,0-16,16v64a16,16,0,0,0,16,16h60v8a32,32,0,0,1-32,32,8,8,0,0,0,0,16,48.05,48.05,0,0,0,48-48V72A16,16,0,0,0,216,56Zm0,80H156V72h60Z"></path>
                                        </svg>
                                    </div>
                                    <p class="lg:text-xl font-semibold text-neutral-900">{{ $post->excerpt }}</p>
                                </div>
                            </div>
                        @endif

                        <div class="flex justify-between items-end gap-4 flex-wrap mb-10 xl:mb-14">
                            <div>
                                <h4 class="mb-4 xl:mb-6">Related Tags</h4>
                                <div class="flex flex-wrap gap-3">
                                    @if($post->tags && $post->tags->count() > 0)
                                        @foreach($post->tags as $tag)
                                            <a href="{{ route('frontend.blog', ['tag' => $tag->slug]) }}" class="px-4 py-2 border border-neutral-40 rounded-lg flex items-center">#{{ $tag->name }}</a>
                                        @endforeach
                                    @else
                                        <a href="#" class="px-4 py-2 border border-neutral-40 rounded-lg flex items-center">#Sustainable Aquaculture</a>
                                        <a href="#" class="px-4 py-2 border border-neutral-40 rounded-lg flex items-center">#Fish Farming</a>
                                @endif
                                </div>
                            </div>
                            <div class="flex items-center gap-2 justify-center">
                                <a href="#" aria-label="social site link" class="social-icon text-primary-300 hover:bg-primary-300 hover:text-neutral-0 border-primary-300 border">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="size-5 xl:size-6" fill="currentColor" viewBox="0 0 256 256">
                                        <path d="M232,128a104.16,104.16,0,0,1-91.55,103.26,4,4,0,0,1-4.45-4V152h24a8,8,0,0,0,8-8.53,8.17,8.17,0,0,0-8.25-7.47H136V112a16,16,0,0,1,16-16h16a8,8,0,0,0,8-8.53A8.17,8.17,0,0,0,167.73,80H152a32,32,0,0,0-32,32v24H96a8,8,0,0,0-8,8.53A8.17,8.17,0,0,0,96.27,152H120v75.28a4,4,0,0,1-4.44,4A104.15,104.15,0,0,1,24.07,124.09c2-54,45.74-97.9,99.78-100A104.12,104.12,0,0,1,232,128Z"></path>
                                    </svg>
                                </a>
                                <a href="#" aria-label="social site link" class="social-icon text-primary-300 hover:bg-primary-300 hover:text-neutral-0 border-primary-300 border">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="size-5 xl:size-6" fill="currentColor" viewBox="0 0 256 256">
                                        <path d="M176,24H80A56.06,56.06,0,0,0,24,80v96a56.06,56.06,0,0,0,56,56h96a56.06,56.06,0,0,0,56-56V80A56.06,56.06,0,0,0,176,24ZM128,176a48,48,0,1,1,48-48A48.05,48.05,0,0,1,128,176Zm60-96a12,12,0,1,1,12-12A12,12,0,0,1,188,80Zm-28,48a32,32,0,1,1-32-32A32,32,0,0,1,160,128Z"></path>
                                    </svg>
                                </a>
                                <a href="#" aria-label="social site link" class="social-icon text-primary-300 hover:bg-primary-300 hover:text-neutral-0 border-primary-300 border">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="size-5 xl:size-6" fill="currentColor" viewBox="0 0 256 256">
                                        <path d="M245.66,77.66l-29.9,29.9C209.72,177.58,150.67,232,80,232c-14.52,0-26.49-2.3-35.58-6.84-7.33-3.67-10.33-7.6-11.08-8.72a8,8,0,0,1,3.85-11.93c.26-.1,24.24-9.31,39.47-26.84a110.93,110.93,0,0,1-21.88-24.2c-12.4-18.41-26.28-50.39-22-98.18a8,8,0,0,1,13.65-4.92c.35.35,33.28,33.1,73.54,43.72V88a47.87,47.87,0,0,1,14.36-34.3A46.87,46.87,0,0,1,168.1,40a48.66,48.66,0,0,1,41.47,24H240a8,8,0,0,1,5.66,13.66Z"></path>
                                    </svg>
                                </a>
                            </div>
                        </div>
                        
                        @if($post->author)
                            <div class="p-4 lg:p-6 xl:p-8 bg-primary-50 rounded-xl flex max-sm:flex-wrap items-start gap-4 mb-10 xl:mb-14">
                                <img src="{{ asset('images/100x100.png') }}" class="rounded-full" width="80" height="80" alt="{{ $post->author->name }}" />
                                <div>
                                    <h5 class="mb-5">{{ $post->author->name }}</h5>
                                    <p class="font-medium mb-5">I can't thank the team enough for this insightful article! The expertise and attention to detail exceeded my expectations.</p>
                                    <div class="flex gap-2">
                                        <a href="#" class="hover:text-secondary text-primary-300 duration-300">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="size-6" fill="currentColor" viewBox="0 0 256 256">
                                                <path d="M232,128a104.16,104.16,0,0,1-91.55,103.26,4,4,0,0,1-4.45-4V152h24a8,8,0,0,0,8-8.53,8.17,8.17,0,0,0-8.25-7.47H136V112a16,16,0,0,1,16-16h16a8,8,0,0,0,8-8.53A8.17,8.17,0,0,0,167.73,80H152a32,32,0,0,0-32,32v24H96a8,8,0,0,0-8,8.53A8.17,8.17,0,0,0,96.27,152H120v75.28a4,4,0,0,1-4.44,4A104.15,104.15,0,0,1,24.07,124.09c2-54,45.74-97.9,99.78-100A104.12,104.12,0,0,1,232,128Z"></path>
                                            </svg>
                                        </a>
                                        <a href="#" class="hover:text-secondary text-primary-300 duration-300">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="size-6" fill="currentColor" viewBox="0 0 256 256">
                                                <path d="M176,24H80A56.06,56.06,0,0,0,24,80v96a56.06,56.06,0,0,0,56,56h96a56.06,56.06,0,0,0,56-56V80A56.06,56.06,0,0,0,176,24ZM128,176a48,48,0,1,1,48-48A48.05,48.05,0,0,1,128,176Zm60-96a12,12,0,1,1,12-12A12,12,0,0,1,188,80Zm-28,48a32,32,0,1,1-32-32A32,32,0,0,1,160,128Z"></path>
                                            </svg>
                                        </a>
                                        <a href="#" class="hover:text-secondary text-primary-300 duration-300">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="size-6" fill="currentColor" viewBox="0 0 256 256">
                                                <path d="M245.66,77.66l-29.9,29.9C209.72,177.58,150.67,232,80,232c-14.52,0-26.49-2.3-35.58-6.84-7.33-3.67-10.33-7.6-11.08-8.72a8,8,0,0,1,3.85-11.93c.26-.1,24.24-9.31,39.47-26.84a110.93,110.93,0,0,1-21.88-24.2c-12.4-18.41-26.28-50.39-22-98.18a8,8,0,0,1,13.65-4.92c.35.35,33.28,33.1,73.54,43.72V88a47.87,47.87,0,0,1,14.36-34.3A46.87,46.87,0,0,1,168.1,40a48.66,48.66,0,0,1,41.47,24H240a8,8,0,0,1,5.66,13.66Z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if($post->allow_comments)
                            <h3 class="uppercase mb-5">Leave a Comment</h3>
                            <p class="mb-7 xl:mb-10">Your email address will not be published. Required fields are marked *</p>
                            <form action="{{ route('frontend.blog.comment') }}" method="POST" class="col-span-12 md:col-span-6 grid grid-cols-2 gap-4 lg:gap-6 xxl:gap-y-8 mb-10 xl:mb-14">
                                @csrf
                                <input type="hidden" name="blog_post_id" value="{{ $post->id }}">
                                <div class="col-span-2 md:col-span-1">
                                    <label for="name" class="s-text font-semibold mb-2 block">Name*</label>
                                    <input type="text" name="name" placeholder="Enter Name" class="py-2 focus:border-primary-300 bg-neutral-0 border-b border-neutral-40 w-full block" required />
                                </div>
                                <div class="col-span-2 md:col-span-1">
                                    <label for="email" class="s-text font-semibold mb-2 block">Email*</label>
                                    <input type="email" name="email" placeholder="Enter Email" class="py-2 focus:border-primary-300 bg-neutral-0 border-b border-neutral-40 w-full block" required />
                                </div>
                                <div class="col-span-2">
                                    <label for="comment" class="s-text font-semibold mb-2 block">Comment*</label>
                                    <textarea name="comment" rows="3" placeholder="Your Comment" class="py-2 focus:border-primary-300 bg-neutral-0 border-b border-neutral-40 w-full block" required></textarea>
                                </div>
                                <div class="col-span-2">
                                    <button type="submit" class="btn-primary !text-neutral-0">Submit Comment</button>
                                </div>
                            </form>
                        @endif

                        @if($relatedPosts && $relatedPosts->count() > 0)
                            <h3 class="mb-10 xl:mb-14">You May Also Like</h3>
                            <div class="cont grid grid-cols-1 lg:grid-cols-2 gap-6">
                                @foreach($relatedPosts as $relatedPost)
                                    <div class="p-4 xl:p-5 rounded-xl border bg-neutral-0 border-neutral-40">
                                        <a href="{{ route('frontend.blog.details', $relatedPost->slug) }}" aria-label="Read News">
                                            <img src="{{ $relatedPost->featured_image ? Storage::url($relatedPost->featured_image) : asset('images/800x600.png') }}" class="rounded-xl mb-5 w-full" alt="{{ $relatedPost->title }}" />
                                        </a>
                                        <div class="mb-5 flex justify-between items-center">
                                            <div class="flex items-center gap-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="size-5 text-primary-300" fill="currentColor" viewBox="0 0 256 256"><path d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"></path></svg>
                                                <span>{{ $relatedPost->author->name ?? 'Admin' }}</span>
                                            </div>
                                            <div class="flex items-center gap-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="size-5 text-primary-300" fill="currentColor" viewBox="0 0 256 256"><path d="M168,112a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,112Zm-8,24H96a8,8,0,0,0,0,16h64a8,8,0,0,0,0-16Zm72-8A104,104,0,0,1,79.12,219.82L45.07,231.17a16,16,0,0,1-20.24-20.24l11.35-34.05A104,104,0,1,1,232,128Zm-16,0A88,88,0,1,0,51.81,172.06a8,8,0,0,1,.66,6.54L40,216,77.4,203.53a7.85,7.85,0,0,1,2.53-.42,8,8,0,0,1,4,1.08A88,88,0,0,0,216,128Z"></path></svg>
                                                <span>{{ $relatedPost->comments->count() }} Comments</span>
                                            </div>
                                        </div>
                                        <h4 class="mb-4">{{ $relatedPost->title }}</h4>
                                        <p class="mb-5 xl:mb-8">{{ Str::limit(strip_tags($relatedPost->excerpt), 100) }}</p>
                                        <a href="{{ route('frontend.blog.details', $relatedPost->slug) }}" class="text-primary-300 text-lg font-medium underline">View Details</a>
                                    </div>
                                @endforeach
                        </div>
                        @endif
                    </div>
                        </div>
            </div>
            <div class="col-span-12 md:col-span-5 xl:col-span-4 space-y-4 xl:space-y-6">
                <div class="box">
                    <h4 class="pb-4 xl:pb-6 text-2xl">Search</h4>
                    <form action="{{ route('frontend.blog') }}" method="GET" class="px-4 py-2 w-full bg-neutral-0 border border-neutral-0 focus-within:border-primary-500 flex items-center gap-2">
                        <input type="text" name="search" placeholder="Search" id="search" class="bg-transparent w-full py-0.5" />
                        <button type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" class="size-5" fill="currentColor" viewBox="0 0 256 256"><path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z"></path></svg>
                        </button>
                    </form>
                    </div>

                <div class="box">
                    <p class="font-semibold text-2xl mb-5">Categories</p>
                    <div class="divide-y divide-neutral-40">
                        @foreach($categories as $category)
                            <a href="{{ route('frontend.blog', ['category' => $category->slug]) }}" class="flex w-full justify-between rounded-lg group items-center duration-300 hover:bg-neutral-0 hover:px-4 py-3.5 gap-3">
                                <p class="m-text font-medium flex items-center gap-1">• {{ $category->name }}</p>
                                <span class="size-10 rounded-sm f-center bg-primary-50 group-hover:text-primary-300">{{ $category->published_posts_count }}</span>
                            </a>
                        @endforeach
                    </div>
                </div>

                <div class="box">
                    <p class="capitalize text-2xl font-semibold mb-5">Recent Posts</p>
                    <div class="space-y-4">
                        @foreach($recentPosts as $recentPost)
                            <div class="flex items-center gap-3">
                                <div class="size-[114px] shrink-0">
                                    <img src="{{ $recentPost->featured_image ? Storage::url($recentPost->featured_image) : asset('images/800x600.png') }}" class="object-cover object-center h-full rounded-md" alt="{{ $recentPost->title }}" />
                                </div>
                                <div>
                                    <p class="text-sm mb-1">{{ $recentPost->created_at->format('F d, Y') }}</p>
                                    <p class="lg:text-lg font-medium mb-1">{{ $recentPost->title }}</p>
                                    <a href="{{ route('frontend.blog.details', $recentPost->slug) }}" class="flex items-center text-sm text-primary-500 gap-2 font-semibold">
                                        Read More 
                                        <svg xmlns="http://www.w3.org/2000/svg" class="size-5" fill="currentColor" viewBox="0 0 256 256">
                                            <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>

                <div class="sticky top-28 text-center text-neutral-0 after:size-full after:bg-neutral-900/70 after:absolute after:inset-0 p-4 md:p-6 py-10 xl:px-14 xl:py-20 after:rounded-2xl rounded-2xl" data-bg="{{ asset('assets/images/cta-bg.webp') }}">
                    <div class="relative z-[2] text-center">
                        <div class="flex justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="size-12 text-neutral-0 mb-3" fill="currentColor" viewBox="0 0 256 256">
                                <path d="M201.89,54.66A103.43,103.43,0,0,0,128.79,24H128A104,104,0,0,0,24,128v56a24,24,0,0,0,24,24H64a24,24,0,0,0,24-24V144a24,24,0,0,0-24-24H40.36A88.12,88.12,0,0,1,190.54,65.93,87.39,87.39,0,0,1,215.65,120H192a24,24,0,0,0-24,24v40a24,24,0,0,0,24,24h24a24,24,0,0,1-24,24H136a8,8,0,0,0,0,16h56a40,40,0,0,0,40-40V128A103.41,103.41,0,0,0,201.89,54.66ZM64,136a8,8,0,0,1,8,8v40a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V136Zm128,56a8,8,0,0,1-8-8V144a8,8,0,0,1,8-8h24v56Z"></path>
                            </svg>
                        </div>
                        <h4 class="mb-5 pb-5 xl:mb-8 xl:pb-8 border-b text-neutral-0 border-neutral-0">How can we help?</h4>
                        <div class="flex justify-center gap-1 mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" class="size-6 text-secondary" fill="currentColor" viewBox="0 0 256 256">
                                <path d="M144.27,45.93a8,8,0,0,1,9.8-5.66,86.22,86.22,0,0,1,61.66,61.66,8,8,0,0,1-5.66,9.8A8.23,8.23,0,0,1,208,112a8,8,0,0,1-7.73-5.93,70.35,70.35,0,0,0-50.33-50.34A8,8,0,0,1,144.27,45.93Zm-2.33,41.8c13.79,3.68,22.65,12.55,26.33,26.34A8,8,0,0,0,176,120a8.23,8.23,0,0,0,2.07-.27,8,8,0,0,0,5.66-9.8c-5.12-19.16-18.5-32.54-37.66-37.66a8,8,0,1,0-4.13,15.46Zm72.43,78.73-47.11-21.11-.13-.06a16,16,0,0,0-15.17,1.4,8.12,8.12,0,0,0-.75.56L126.87,168c-15.42-7.49-31.34-23.29-38.83-38.51l20.78-24.71c.2-.25.39-.5.57-.77a16,16,0,0,0,1.32-15.06l0-.12L89.54,41.64a16,16,0,0,0-16.62-9.52A56.26,56.26,0,0,0,24,88c0,79.4,64.6,144,144,144a56.26,56.26,0,0,0,55.88-48.92A16,16,0,0,0,214.37,166.46Z"></path>
                                </svg>
                            <span class="text-neutral-0 font-medium">+1 234 56 890</span>
                        </div>
                        <div class="flex justify-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" class="size-6 text-secondary" fill="currentColor" viewBox="0 0 256 256"><path d="M228.44,89.34l-96-64a8,8,0,0,0-8.88,0l-96,64A8,8,0,0,0,24,96V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V96A8,8,0,0,0,228.44,89.34ZM40,200V111.53l65.9,47a8,8,0,0,0,4.65,1.49h34.9a8,8,0,0,0,4.65-1.49l65.9-47V200Z"></path></svg>
                            <span class="text-neutral-0 font-medium">addyour@emailhere</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog Details section end -->

    @include('frontend.layouts.footer')
</body>
</html>