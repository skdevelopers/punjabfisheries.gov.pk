{{-- resources/views/frontend/blogs.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Department of Fisheries, Government of the Punjab — latest news, updates and insights about fisheries development, aquaculture and marine conservation." />
  <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-eval' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com https://cdn.plyr.io; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.plyr.io; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'; media-src 'self' https:; object-src 'none'; base-uri 'self'; form-action 'self';" />
  <link rel="shortcut icon" href="{{ asset('assets/images/favicon.ico') }}" type="image/x-icon" />
  <link rel="preconnect" href="https://fonts.googleapis.com/" />
  <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
  <link rel="stylesheet" href="{{ asset('assets/css/swiper.min.css') }}" />
  <link rel="stylesheet" href="{{ asset('assets/css/glightbox.css') }}" />
  <title>Blogs — Department of Fisheries, Government of the Punjab</title>
  <script defer src="{{ asset('assets/js/app.min.js') }}"></script>
  <link href="{{ asset('assets/css/styles.css') }}" rel="stylesheet">
</head>

<body>
  {{-- Loader --}}
  <div class="screen_loader fixed inset-0 z-[101] grid place-content-center bg-neutral-0">
    <div class="w-10 h-10 border-4 border-t-primary-400 border-neutral-40 rounded-full animate-spin"></div>
  </div>

  @include('frontend.layouts.header')

  {{-- Banner --}}
  <section class="px-3">
    <div class="max-w-[1800px] mx-auto bg-primary-50 rounded-xl xl:rounded-2xl py-14 xl:py-28 flex justify-center text-center">
      <div class="relative z-[1]">
        <h1 class="text-4xl xl:text-5xl font-bold text-neutral-900 mb-6">Our Blog</h1>
        <p class="text-lg text-neutral-600 max-w-2xl mx-auto">Stay updated with the latest news, insights, and updates from the Department of Fisheries - Punjab.</p>
      </div>
    </div>
  </section>

  {{-- Blog Posts Section --}}
  <section class="py-16 xl:py-20">
    <div class="cont">
      @if(isset($posts) && $posts->count() > 0)
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 xl:gap-8">
          @foreach($posts as $post)
            <article class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              @if($post->featured_image)
                <div class="aspect-w-16 aspect-h-9">
                  <img src="{{ Storage::url($post->featured_image) }}" 
                       alt="{{ $post->title }}" 
                       class="w-full h-48 object-cover">
                </div>
              @endif
              
              <div class="p-6">
                <div class="flex items-center justify-between mb-3">
                  <span class="text-sm text-gray-500">{{ $post->created_at->format('M d, Y') }}</span>
                  @if($post->category)
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                      {{ $post->category }}
                    </span>
                  @endif
                </div>
                
                <h3 class="text-xl font-semibold text-gray-900 mb-3 line-clamp-2">
                  {{ $post->title }}
                </h3>
                
                <p class="text-gray-600 mb-4 line-clamp-3">
                  {{ Str::limit(strip_tags($post->content), 120) }}
                </p>
                
                <div class="flex items-center justify-between">
                  <a href="{{ route('frontend.blog.details', $post->slug) }}" 
                     class="inline-flex items-center text-primary-600 hover:text-primary-800 font-medium text-sm">
                    Read More
                    <svg xmlns="http://www.w3.org/2000/svg" class="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                  </a>
                  
                  <div class="flex items-center text-sm text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="currentColor" viewBox="0 0 256 256">
                      <path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Z"></path>
                    </svg>
                    {{ $post->views ?? 0 }} views
              </div>
            </div>
              </div>
            </article>
          @endforeach
      </div>

      {{-- Pagination --}}
        <div class="mt-12 flex justify-center">
          {{ $posts->links() }}
        </div>
      @else
        <div class="text-center py-20">
          <div class="mb-8">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-24 w-24 mx-auto text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
            </svg>
          </div>
          <h3 class="text-2xl font-semibold text-gray-700 mb-4">No Blog Posts Available</h3>
          <p class="text-gray-500 mb-8">We currently don't have any blog posts. Please check back later for updates.</p>
          <a href="{{ route('frontend.contact') }}" class="btn-primary">Contact Us</a>
        </div>
      @endif
    </div>
  </section>

  @include('frontend.layouts.footer')
</body>
</html>